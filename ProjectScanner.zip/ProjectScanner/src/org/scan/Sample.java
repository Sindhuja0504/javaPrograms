package org.scan;

import java.util.Scanner;

public class Sample {
	
	
	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		
		System.out.println("Enter the boolean value");
		System.out.println("Boolean value: " + scr.nextBoolean());
		System.out.println("Enter the Byte value");
		System.out.println("Byte value: " + scr.nextByte());
		System.out.println("Enter the Double value");
		System.out.println("Double value: " + scr.nextDouble());
		System.out.println("Enter the Float value");
		System.out.println("Float value: " + scr.nextFloat());
		System.out.println("Enter the Int value");
		System.out.println("Int value: " + scr.nextInt());
		System.out.println("Enter the String value");
		System.out.println("String value: " + scr.next());
		System.out.println("Enter the Short value");
		System.out.println("Short value: " + scr.nextShort());
		
		
	
	}


}
