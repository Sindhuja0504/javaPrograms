package org.scan;

public class Sampl1 {
	//int a = 5;
	/*void s() {
		System.out.println(a);
		int b =6;
	}*/
 public static void main (String args[]) {
	 int a = 5;
	 System.out.println(a);
	 System.out.print(a);
	 System.out.println(a );
	 System.out.print(a);
	 System.out.print(a);
	 System.out.println(a);
	 System.out.print(a);
	 System.out.print(a);
	 System.out.print(a);
	 System.out.print(a);

 }
 /*void s1() {
		System.out.println(a);
		System.out.println(b);
	}*/
}
